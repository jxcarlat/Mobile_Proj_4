package edu.ualr.jxcarlat.gameengine

import android.graphics.*
import android.util.Log
import kotlin.math.abs
//The Player class inherits from the GameObject class just like all of the other classes
//using inheritance. Each of these classes will contain some variation in some form or another
//but all of them will need their Bitmap initialized as well as their starting positions on the
//screen
class Player(image: Bitmap?, x: Float, y: Float, w: Float, h: Float) : GameObject(image, x, y, w, h) {
    //We have some variables associated with our Player class, we need two booleans to let us know
    //if the player won or if he died. These will come in handy when we deal with collision detection.
    //The maxVelocityX and maxVelocityY variables handle our terminal velocity in the x and y directions.
    //deltaX and deltaY handle our change in velocity. We have movingLeft, movingRight, movingUp, and
    //movingDown boolean variables to handle the true and false conditions of player movement.
    var isDead: Boolean = false
    var hasWon: Boolean = false
    var maxVelocityX: Float = 50f
    var maxVelocityY: Float = 50f
    var deltaX: Float = 0f
    var deltaY: Float = 0f

    var movingLeft: Boolean = false
    var movingRight: Boolean = true
    var movingUp: Boolean = false
    var movingDown: Boolean = true
    //initialize our monitorCollisions variable to true to handle collision detection and
    //velocityY to 10f so that as we are falling from the sky we land on a block and not stay
    //stuck in the air.
    init {
        monitorCollisions = true

        velocityY = 10f
    }
    //This function will draw the player to the screen. If our image is properly loaded then
    //we run through another if statement. If the player is moving left then flip the bitmap image
    //so that the movement actually looks like the player is moving left and not backwards, else
    //just draw the bitmap image as usual. If we don't have an image then load up a rectangle in
    //its place.
    override fun draw(canvas: Canvas) {
        if(image != null)
        {
            // Rotate the image 180 degrees if we're moving left
            if(movingLeft) {
                canvas.drawBitmap(image!!.flip(), x, y, null)
            }
            else {
                canvas.drawBitmap(image, x, y, null)
            }
        }
        else {
            val brush = Paint()
            brush.setARGB(255, 63, 63, 255)

            canvas.drawRect(x, y, (x + w), (y + h), brush)
        }
    }
    //Our update function will be called constantly throughout the game. This will handle our player
    //and enemy movement; We have our lastX variable be assigned to our x position and our lastY
    //variable assigned to our y position. We also initialize our lastVelocityX and lastVelocityY
    //values to our current velocity in the x position and current velocity in the y position.
    //We add in our change in velocity in the x position and y position to simulate movement.
    override fun update() {
        lastX = x
        lastY = y

        val lastVelocityX = velocityX
        val lastVelocityY = velocityY

        velocityX += deltaX
        velocityY += deltaY
        //If our last x velocity value is less than 0f and our current velocity in the x direction
        //is greater than or equal to 0f then our change in velocity is 0f and our velocity in the
        //x direction is set to 0f. Same thing for the opposite case, this handles any kind of errors
        //that may appear by having some value in one and not the other.
        if (lastVelocityX < 0f && velocityX >= 0f) {
            deltaX = 0f
            velocityX = 0f
        }else if (lastVelocityX > 0f && velocityX <= 0f) {
            deltaX = 0f
            velocityX = 0f
        }

        // Add quasi-gravity
        //If we happen to move in the y direction and have not hit terminal velocity, keep adding
        //to velocityY to simulate gravity.
        if (velocityY < maxVelocityY) {
            velocityY += 10f
        }
        //If at any point we have a calculation that's greater than terminal velocity immediately
        //set back to terminal velocity.
        if (velocityY > maxVelocityY) {
            velocityY = maxVelocityY
        }
        //If our velocity in the y direction changes in an upwards direction (We hit a spring)
        //and our velocityY is less than (for negative values) maxVelocityY then set velocityY
        //to our terminal velocity in the y direction heading upwards. Notice that our first if
        //statement will keep adding more into velocityY, gravity is always affecting our game objects
        //and will bring them down sooner or later.
        if (velocityY < maxVelocityY * -1f) {
            velocityY = maxVelocityY * -1f
        }
        //If we haven't hit terminal velocity in the x direction and our velocityX is greater than
        //assign our terminal velocity x to velocityX. This helps keep things from flying at insane
        //speeds all over the game map.
        if (velocityX > maxVelocityX) {
            velocityX = maxVelocityX
        }
        //We handle the same case scenario heading in the opposite direction (left).
        if (velocityX < maxVelocityX * -1f) {
            velocityX = maxVelocityX * -1f
        }
        //We change the position of our game object accordingly adding our velocity values into
        //our x and y position.
        x += velocityX
        y += velocityY


    }
    //We process the collisions in our player class. We set our collisionResolved variable equal
    //to false and deal with our collidedWith argument. If our lastX position doesn't equal our
    //current x position then the movingLeft function is activated when our lastX position is greater
    //than our initial x and movingRight is activated when our lastX position is less than our initial
    //x. We do the same thing for our y position activating the movingUp function when our lastY is
    //greater than our initial y and movingDown when our lastY is less than our initial y.
    override fun processCollision(collidedWith: GameObject) {
        var collisionResolved = false

        if (lastX != x) {
            movingLeft = lastX > x
            movingRight = lastX < x
        }

        if (lastY != y) {
            movingUp = lastY > y
            movingDown = lastY < y
        }

        //We initialize our boolean variables fixY and fixX to false. This will handle cases where
        //we've come into contact with objects.
        var fixY = false
        var fixX = false
        //If we are currently moving downwards and our last y position plus our height is less than
        //or equal to the object we collidedWith's y position as well as our y position combined with
        //our height happens to be less than the collided object's y position then set our fixY
        //variable to true.
        if (movingDown && lastY + h <= collidedWith.y && y + h > collidedWith.y) {
            // We've moved down into the object
            fixY = true
        }
        //We do the same thing if we happen to move upwards into an object.
        if (movingUp && lastY >= collidedWith.y + collidedWith.h && y < collidedWith.y + collidedWith.h)
        {
            // We've moved up into the object
            fixY = true
        }
        //We also do the same thing when we move right into an object dealing with their x position
        //and our x position instead. Be sure to set fixX to true instead of fixY.
        if (movingRight && lastX + w <= collidedWith.x && x + w > collidedWith.x) {
            // We've moved right into the object
            fixX = true
        }
        //so on and so forth.
        if (movingLeft && lastX >= collidedWith.x + collidedWith.w && x < collidedWith.x + collidedWith.w)
        {
            // We've moved left into the object
            fixX = true
        }
        //If the object we came into contact with is a Pit and we fell down into it (not moving right
        //or left into it) then return isDead variable true, return collisionResolved variable
        // to true and display the game over screen. End game.
        if (collidedWith is Pit) {
            if (movingDown) {
                isDead = true
            }

            collisionResolved = true
        }
        //Same thing when we collide with the Enemy object. Doesn't matter how you touch this
        //game object, one touch and you die. Resolve the collision and end game.
        else if(collidedWith is Enemy){
            isDead = true

            collisionResolved = true
        }
        //If we collide with the GoalPost object however, we return the hasWon variable with value
        //of true, resulting in the game won screen and end the game. We also return the collision
        //being resolved boolean variable true.
        else if(collidedWith is GoalPost) {
            hasWon = true

            collisionResolved = true
        }
        //If we collide with a solid surface in the game we handle this a number of ways depending
        //on how we moved.
        else if (collidedWith is SolidSurface) {
            //If we moved right into the surface and the fixX boolean variable returns true than
            //set our x position with the collided object's x position, subtracted by its width, and
            //subtracted by 1f. This will stop us from moving inside the solid surface and will stop
            //us just outside of the object. Our velocity in the x position is also set to zero,
            //simulating a complete stop. Return collision resolved to true.
            if (movingRight && fixX) {
                x = collidedWith.x - w - 1f
                velocityX = 0f
                collisionResolved = true
            }
            //Same thing is done when moving in the left direction. Just have to add collideWith
            //object's width and 1f to keep player from moving into the surface.
            if (movingLeft && fixX) {
                x = collidedWith.x + collidedWith.w + 1f
                velocityX = 0f
                collisionResolved = true
            }
            //If we happen to be moving downwards into the surface and fixY is equal to true, then
            //we set our y position to our collided object's y position minus our height minus 1f.
            //This keeps us from falling into the object surface and in a way simulates the normal
            //force.
            if ((movingDown) && fixY) {
                y = collidedWith.y - h - 1f
                collisionResolved = true
            }
            //If we move up into a surface add the collided object's height and 1f instead to keep
            //player from moving upwards into the surface. In all these cases return collision Resolved
            //boolean variable to true.
            if (movingUp && fixY) {
                y = collidedWith.y + collidedWith.h + 1f
                collisionResolved = true
            }
        }
        //If we happen to collide with a Spring object than add -60f to our velocity in the y direction.
        //This will cause us to bounce upwards and hit terminal y velocity briefly before gravity brings
        //us back down.
        else if(collidedWith is Spring) {
            velocityY = -60f
            collisionResolved = true
        }
        //If there is ever an instance where our collisions don't get resolved than be sure to
        //put this into our log for debugging purposes.
        if (!collisionResolved) {
            Log.d("GAME_UTIL", "Unresolved Collision")
        }
    }
    //This function will handle cases when the player is moving left. If the absolute value
    //of our X velocity is less than our terminal X velocity than we can keep adding onto our
    //velocity headed in the leftwards direction. If it's greater than set our velocity X to our
    //terminal x velocity in the left direction.
    fun moveLeft() {
        if (abs(velocityX) < maxVelocityX) {
            velocityX -= 10f

            if (abs(velocityX) > maxVelocityX) {
                velocityX = maxVelocityX * -1f
            }
        }
    }
    //We do virtually the same thing for the moveRight function only we are dealing with positive
    //values instead of negative values in dealing with right momentum.
    fun moveRight() {
        if (velocityX < maxVelocityX) {
            velocityX += 10f

            if(velocityX > maxVelocityX) {
                velocityX = maxVelocityX
            }
        }
    }
    //If we are not moving and our x velocity is greater than zero then set our change in velocity in
    //the x position to -10f. If it happens to be less than zero than set our change to be 10f.
    fun moveButtonUp() {
        if (velocityX > 0) {
            deltaX = -10f
        }
        if (velocityX < 0) {
            deltaX = 10f
        }
    }
}